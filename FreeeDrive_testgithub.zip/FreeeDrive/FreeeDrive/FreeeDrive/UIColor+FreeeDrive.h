
// KL

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIColor (FreeeDrive)

+ (UIColor *)blueishColor;
+ (UIColor *)bleuColor;
+ (UIColor *)bleuishColor;

@end
