//
//  cell_menu.m
//  EddystoneScannerSample
//
//  Created by user on 4/01/2017.
//
//

#import "cell_menu.h"

@implementation cell_menu

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
