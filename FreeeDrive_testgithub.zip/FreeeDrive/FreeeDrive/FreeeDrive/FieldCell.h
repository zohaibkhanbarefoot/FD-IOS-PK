//
//  FieldCell.h
//  FreeeDriveStore
//
//  Created by KL on 3/28/16.
//  Copyright © 2016 Cole Street. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FieldCell : UITableViewCell

@end
